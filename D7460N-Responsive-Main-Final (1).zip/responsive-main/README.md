# D7460N Responsive Main — Automation Integrated
... (shortened for brevity in this code block)
