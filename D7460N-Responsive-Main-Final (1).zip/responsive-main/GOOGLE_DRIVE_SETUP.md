# Google Drive Backup Setup (rclone)

## 1. Install rclone
```bash
curl https://rclone.org/install.sh | sudo bash
```

## 2. Configure remote access
```bash
rclone config
```
- Choose: `n` for new remote
- Name: `gdrive`
- Type: `drive`
- Follow prompts to authorize your Google account

## 3. Test upload
```bash
rclone copy snapshots-backup-YYYYMMDD-HHMM.zip gdrive:d7460n-snapshots
```

## 4. Hook Integration
Add this line to your `.git/hooks/pre-commit`:
```bash
./infra/auto-backup.sh >> snapshots/logs/backup-output.log 2>&1
```
